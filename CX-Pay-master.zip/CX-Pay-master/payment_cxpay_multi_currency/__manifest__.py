# -*- coding: utf-8 -*-

{
    'name': 'CX Pay Payment Acquirer With multi currency',
    'category': 'Accounting/Payment',
    'summary': 'Payment Acquirer: CX pay Implementatxion with multi currency',
    'version': '13.0.0.1.3',
    'description': """CX pay Payment Acquirer""",
    'depends': ['payment', 'website_sale'],
    'data': [],
    'installable': True,
}
